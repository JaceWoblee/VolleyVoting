'use server'


import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { cookies } from 'next/headers';
import dbConnect from '@/lib/db';
import Vote from '@/models/Vote';
import User from '@/models/User';
import Message from '@/models/Message';
import Exercise from "@/models/Exercise"; 
import SurveyResponse from "@/models/SurveyResponse";
import Poll from '@/models/Poll';
import PollVote from '@/models/PollVote';
export async function handleVote(formData: FormData) {
  // 1. Read the cookie to find out who is voting
  const cookieStore = await cookies();
  const session = cookieStore.get('player_session');
  
  if (!session) return { error: "Nicht eingeloggt. Bitte neu laden." };
  const shirtNumber = Number(session.value); // We get the ID securely from the cookie!

  await dbConnect();

  const mentalSupport = formData.get('mentalSupport') as string;
  const bonusTarget = formData.get('bonusTarget') as string;
  const bonusReason = formData.get('bonusReason') as string;

  if (!mentalSupport || !bonusTarget || !bonusReason.trim()) {
    return { error: "Bitte fülle alle Voting-Felder aus!" };
  }

  // 2. We no longer check the PIN here, because the cookie proves they are logged in!
  const user = await User.findOne({ shirtNumber });
  if (!user || user.hasVoted) return { error: "Bereits abgestimmt." };

  try {
    const targetUser = await User.findOne({ name: bonusTarget });
    if (!targetUser) return { error: "Zielspielerin nicht gefunden." };

    await Vote.create({ shirtNumber, mentalSupport, bonusTarget, bonusReason });

    await User.updateOne({ name: mentalSupport }, { $inc: { votes: 1 } });
    await User.updateOne({ name: bonusTarget }, { $inc: { votes: 1 } });

    await Message.create({
      shirtNumber: targetUser.shirtNumber,
      playerName: "ExtraPunkt", 
      text: bonusReason,
      isAnonymous: true,
      forPlayer: true 
    });

    user.hasVoted = true;
    await user.save();
    revalidatePath('/admin');
  } catch (e: any) {
    return { error: "Fehler: " + e.message };
  }
  
  // CHANGE THIS LINE:
  redirect('/home'); 
}

export async function syncUserVotes() {
  await dbConnect();
  
  const SEASON_START = new Date('2026-09-01');
  
  // Only sync votes from the current season
  const allVotes = await Vote.find({ createdAt: { $gte: SEASON_START } });
  const allUsers = await User.find({});

  for (const user of allUsers) {
    const count = allVotes.filter(v => {
      return v.mentalSupport === user.name || v.bonusTarget === user.name;
    }).length;

    await User.updateOne(
      { _id: user._id }, 
      { $set: { votes: count } }
    );
  }

  revalidatePath('/admin');
  return { success: true };
}

export async function startNewMatch() {
  await dbConnect();
  
  // Reset everyone's voting status
  await User.updateMany({}, { hasVoted: false });
  
  // This tells Next.js to refresh the Admin page data
  revalidatePath('/admin');
}

export async function seedTeam() {
  await dbConnect();
  
  const players = [
    { shirtNumber: 0, name: "Yasha", pin: "1337", hasVoted: false, needsPasswordChange: false },
    { shirtNumber: 1, name: "Test Dummy", pin: "1234", hasVoted: false, needsPasswordChange: true },
    { shirtNumber: 3, name: "Eda", pin: "1234", hasVoted: false, needsPasswordChange: true },
    { shirtNumber: 4, name: "Laura", pin: "1234", hasVoted: false, needsPasswordChange: true },
    { shirtNumber: 5, name: "Eli", pin: "1234", hasVoted: false, needsPasswordChange: true },
    { shirtNumber: 7, name: "Elonie", pin: "1234", hasVoted: false, needsPasswordChange: true },
    { shirtNumber: 9, name: "Yarina", pin: "1234", hasVoted: false, needsPasswordChange: true },
    { shirtNumber: 10, name: "Seraina", pin: "1234", hasVoted: false, needsPasswordChange: true },
    { shirtNumber: 11, name: "Ainoa", pin: "1234", hasVoted: false, needsPasswordChange: true },
    { shirtNumber: 14, name: "Jeanne", pin: "1234", hasVoted: false, needsPasswordChange: true },
    { shirtNumber: 18, name: "Anaïs", pin: "1234", hasVoted: false, needsPasswordChange: true },
    { shirtNumber: 21, name: "Vera", pin: "1234", hasVoted: false, needsPasswordChange: true },
    { shirtNumber: 22, name: "Sofia", pin: "1234", hasVoted: false, needsPasswordChange: true },
    { shirtNumber: 32, name: "Maria", pin: "1234", hasVoted: false, needsPasswordChange: true },
    { shirtNumber: 82, name: "Tina", pin: "1234", hasVoted: false, needsPasswordChange: true },
  ];

  try {
    await User.deleteMany({}); 
    await User.insertMany(players);
    revalidatePath('/admin');
    return { success: true }; // Added return for safety
  } catch (e) {
    console.error("Seed Error:", e);
    return { error: "Seed failed" };
  }
}

export async function verifyLogin(shirtNumber: number, pin: string) {
  await dbConnect();
  const user = await User.findOne({ shirtNumber, pin });
  
  if (!user) return { error: "Ungültige Eingabe." };

  const cookieStore = await cookies();

  // Admin Login
  if (user.shirtNumber === 0) {
    cookieStore.set('admin_session', 'authenticated', { 
      httpOnly: true, secure: process.env.NODE_ENV === 'production', maxAge: 60 * 60 * 2, path: '/' 
    });
    return { success: true, isAdmin: true };
  }

  // NEW: Player Login - We save their shirt number in the cookie
  cookieStore.set('player_session', user.shirtNumber.toString(), { 
    httpOnly: true, secure: process.env.NODE_ENV === 'production', maxAge: 60 * 60 * 24 * 7, path: '/' 
  });

  return { 
    success: true, 
    isAdmin: false,
    userName: user.name,
    needsPasswordChange: user.needsPasswordChange 
  };
}

export async function logout() {
  const cookieStore = await cookies();
  cookieStore.delete('admin_session');
  cookieStore.delete('player_session'); // Ensure player is logged out too
  redirect('/');
}

export async function resetPlayerPin(shirtNumber: number) {
  await dbConnect();
  await User.findOneAndUpdate(
    { shirtNumber }, 
    { pin: "1234", needsPasswordChange: true }
  );
  revalidatePath('/admin');
}

export async function updatePin(shirtNumber: number, oldPin: string, newPin: string) {
  await dbConnect();
  if (newPin.length < 4) return { error: "PIN muss mindestens 4 Zeichen beinhalten." };
  
  const user = await User.findOneAndUpdate(
    { shirtNumber, pin: oldPin },
    { pin: newPin, needsPasswordChange: false },
    { new: true }
  );

  if (!user) return { error: "Konnte den PIN nicht updaten." };
  return { success: true };
}

export async function giveCoachBonus(targetShirtNumber: number, reason: string) {
  await dbConnect();
  try {
    // 1. Find the target player's name
    const targetUser = await User.findOne({ shirtNumber: targetShirtNumber });
    if (!targetUser) return { error: "Spielerin nicht gefunden." };

    // 2. Create a "Fake" Vote entry so the Scoreboard and Sync see it
    // We put the name in bonusTarget so it counts as 1 point
    await Vote.create({
      shirtNumber: 0, // 0 represents the Coach/Admin
      mentalSupport: "Anzahl bonus Votes", // Placeholder for the first category
      bonusTarget: targetUser.name, 
      bonusReason: reason,
    });

    // 3. Update the User's point counter immediately
    await User.updateOne(
      { shirtNumber: targetShirtNumber },
      { $inc: { votes: 1 } }
    );

    // 4. Create the message for the player's inbox
    await Message.create({
      shirtNumber: targetShirtNumber,
      playerName: "Yasha",
      text: reason,
      isAnonymous: false,
      forPlayer: true
    });

    revalidatePath('/admin');
    return { success: true };
  } catch (e) {
    return { error: "Bonus konnte nicht vergeben werden." };
  }
}

export async function getPlayerMessages(shirtNumber: number) {
  await dbConnect(); //
  try {
    // We only want messages sent TO this player
    const messages = await Message.find({ shirtNumber }).sort({ createdAt: -1 }).lean();
    return { messages: JSON.parse(JSON.stringify(messages)) };
  } catch (e) {
    return { error: "Failed to load messages" };
  }
}

// src/app/actions.ts
export async function sendFeedback(
  shirtNumber: number, 
  playerName: string, 
  text: string, 
  isAnonymous: boolean
){
  await dbConnect();
  try {
    await Message.create({ 
      shirtNumber, 
      playerName, 
      text, 
      isAnonymous,
      forPlayer: false 
    });
    revalidatePath('/admin');
    return { success: true };
  } catch (e) {
    console.error("Feedback Fehler:", e);
    return { error: "Konnte die Nachricht nicht speichern." };
  }
}

export async function createExercise(formData: any, player: any) {
  try {
    await dbConnect();
    await Exercise.create({
      title: formData.title || "Unbenannte Übung", // Fallback if they leave title empty
      description: formData.description || "",
      videoLink: formData.videoLink || "",
      createdBy: player.shirtNumber,
      playerName: player.name
    });
    revalidatePath('/exercises');
    return { success: true };
  } catch (e) {
    return { error: "Fehler beim Speichern." };
  }
}

export async function deleteExercise(id: string, shirtNumber: number) {
  await dbConnect();
  // Admin (shirtNumber 0) can delete anything. Players can only delete their own.
  if (shirtNumber === 0) {
    await Exercise.findByIdAndDelete(id);
  } else {
    await Exercise.findOneAndDelete({ _id: id, createdBy: shirtNumber });
  }
  revalidatePath('/exercises');
}

export async function editExercise(id: string, formData: any, shirtNumber: number) {
  await dbConnect();
  try {
    const exercise = await Exercise.findById(id);
    if (!exercise) return { error: "Übung nicht gefunden." };

    // Security: Only the creator or the Admin can edit
    if (shirtNumber !== 0 && exercise.createdBy !== shirtNumber) {
      return { error: "Keine Berechtigung." };
    }

    exercise.title = formData.title;
    exercise.description = formData.description;
    exercise.videoLink = formData.videoLink;
    await exercise.save();

    revalidatePath('/exercises');
    return { success: true };
  } catch (e) {
    return { error: "Fehler beim Bearbeiten." };
  }
}

export async function submitSurvey(answers: string[]) {
  await dbConnect();
  try {
    // We create a database entry for every non-empty answer
    const promises = answers.map((text, index) => {
      if (!text.trim()) return null; // Skip if optional question 7 is empty
      return SurveyResponse.create({
        questionNumber: index + 1,
        answer: text.trim()
      });
    });

    await Promise.all(promises.filter(p => p !== null));
    return { success: true };
  } catch (e) {
    console.error(e);
    return { error: "Fehler beim Speichern der Umfrage." };
  }
}

export async function getExercises() {
  await dbConnect();
  // We convert it to a plain object so Next.js doesn't complain
  const data = await Exercise.find({}).sort({ createdAt: -1 });
  return JSON.parse(JSON.stringify(data));
}

export async function createPoll(question: string, type: 'text' | 'options', optionsStr: string, requireReason: boolean = false) {
  await dbConnect();
  try {
    const options = type === 'options' 
      ? optionsStr.split(',').map(opt => opt.trim()).filter(opt => opt.length > 0)
      : [];
    await Poll.create({ question, type, options, requireReason, isActive: true });
    revalidatePath('/admin');
    return { success: true };
  } catch (error) {
    return { error: "Failed to create poll." };
  }
}

export async function togglePollStatus(pollId: string, currentStatus: boolean) {
  await dbConnect();
  try {
    await Poll.findByIdAndUpdate(pollId, { isActive: !currentStatus });
    revalidatePath('/admin');
    return { success: true };
  } catch (error) {
    return { error: "Failed to update poll status." };
  }
}

export async function submitPollVote(pollId: string, shirtNumber: number, playerName: string, answer: string, reason: string = "") {
  await dbConnect();
  try {
    const existingVote = await PollVote.findOne({ pollId, shirtNumber });
    if (existingVote) return { error: "Du hast bereits abgestimmt." };

    await PollVote.create({ pollId, shirtNumber, playerName, answer, reason });
    revalidatePath('/home'); 
    revalidatePath('/admin'); 
    return { success: true };
  } catch (error) {
    return { error: "Fehler beim Abstimmen." };
  }
}

export async function exemptPlayer(shirtNumber: number) {
  await dbConnect();
  try {
    // Setting hasVoted to true removes them from the pending list
    await User.findOneAndUpdate({ shirtNumber }, { hasVoted: true });
    revalidatePath('/admin');
    return { success: true };
  } catch (error) {
    return { error: "Failed to excuse player." };
  }
}

// CREATE PLAYER
export async function createPlayer(formData: { name: string; shirtNumber: number; role: string; pin?: string }) {
  await dbConnect();
  try {
    const existing = await User.findOne({ shirtNumber: formData.shirtNumber });
    if (existing) {
      return { error: `Trikotnummer #${formData.shirtNumber} ist bereits vergeben!` };
    }

    const defaultPin = formData.pin?.trim() || String(formData.shirtNumber).padStart(4, '0');

    await User.create({
      name: formData.name.trim(),
      shirtNumber: formData.shirtNumber,
      role: formData.role || 'Unassigned',
      pin: defaultPin,
      needsPasswordChange: true
    });

    revalidatePath('/admin');
    revalidatePath('/admin/attendance');
    return { success: true };
  } catch (err: any) {
    return { error: err.message || 'Fehler beim Erstellen der Spielerin' };
  }
}

// UPDATE PLAYER (Name, Number, Role)
export async function updatePlayer(oldShirtNumber: number, data: { name: string; shirtNumber: number; role: string }) {
  await dbConnect();
  try {
    if (data.shirtNumber !== oldShirtNumber) {
      const existing = await User.findOne({ shirtNumber: data.shirtNumber });
      if (existing) {
        return { error: `Trikotnummer #${data.shirtNumber} ist bereits vergeben!` };
      }
    }

    await User.findOneAndUpdate(
      { shirtNumber: oldShirtNumber },
      { 
        $set: { 
          name: data.name.trim(), 
          shirtNumber: data.shirtNumber, 
          role: data.role 
        } 
      }
    );

    revalidatePath('/admin');
    revalidatePath('/admin/attendance');
    return { success: true };
  } catch (err: any) {
    return { error: err.message || 'Fehler beim Aktualisieren' };
  }
}

// DELETE PLAYER
export async function deletePlayer(shirtNumber: number) {
  await dbConnect();
  try {
    await User.findOneAndDelete({ shirtNumber });
    revalidatePath('/admin');
    revalidatePath('/admin/attendance');
    return { success: true };
  } catch (err: any) {
    return { error: err.message || 'Fehler beim Löschen' };
  }
}